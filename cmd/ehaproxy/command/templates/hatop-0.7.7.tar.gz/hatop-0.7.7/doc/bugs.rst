.. _bugs:


********************
Bugs and suggestions
********************

For now, please contact us directly at bugs@feurix.org. Thanks! :-)

*Please note your exact HAProxy and Python version in the bug report!*

