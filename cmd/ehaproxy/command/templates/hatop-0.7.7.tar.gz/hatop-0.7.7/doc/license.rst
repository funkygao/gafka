.. _license:


*********************
License and Copyright
*********************

HATop, all of it's modules and this documentation is:

Copyright © 2009-2010 John Feuerstein. All rights reserved.

-------

.. literalinclude:: ../LICENSE
