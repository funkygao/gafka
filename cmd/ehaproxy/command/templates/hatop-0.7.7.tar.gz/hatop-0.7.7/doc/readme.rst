.. _readme:

.. include:: ../README

