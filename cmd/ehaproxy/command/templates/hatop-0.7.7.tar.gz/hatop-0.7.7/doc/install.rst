.. _install:

.. include:: ../INSTALL

